#ifndef lint
static const char yysccsid[] = "@(#)yaccpar	1.9 (Berkeley) 02/21/93";
#endif

#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define YYPATCH 20110908

#define YYEMPTY        (-1)
#define yyclearin      (yychar = YYEMPTY)
#define yyerrok        (yyerrflag = 0)
#define YYRECOVERING() (yyerrflag != 0)

#define YYPREFIX "yy"

#define YYPURE 0

#line 2 "grammar.y"
/******************************************************************************
 * File: grammar.y
 * Authors: Evelina Arthursson, Derek McLean, Hugo Ribeiro
 *      *original content: Carol Zander
 * This is a grammar file that defines the grammar rules for a Pascal-like
 * language.
 * 10/16 - It currently only displays the text of unique identifiers (not
 *         keywords or symbols).
 */

/* declarations section */
#include "actions.h"
#include "parser.h"

#include <stdio.h>
#include <iostream>
#include <vector>

using namespace std;

#line 40 "y.tab.c"

/* compatibility with bison */
#ifdef YYPARSE_PARAM
/* compatibility with FreeBSD */
# ifdef YYPARSE_PARAM_TYPE
#  define YYPARSE_DECL() yyparse(YYPARSE_PARAM_TYPE YYPARSE_PARAM)
# else
#  define YYPARSE_DECL() yyparse(void *YYPARSE_PARAM)
# endif
#else
# define YYPARSE_DECL() yyparse(void)
#endif

/* Parameters sent to lex. */
#ifdef YYLEX_PARAM
# define YYLEX_DECL() yylex(void *YYLEX_PARAM)
# define YYLEX yylex(YYLEX_PARAM)
#else
# define YYLEX_DECL() yylex(void)
# define YYLEX yylex()
#endif

/* Parameters sent to yyerror. */
#define YYERROR_DECL() yyerror(const char *s)
#define YYERROR_CALL(msg) yyerror(msg)

extern int YYPARSE_DECL();

#define yand 257
#define yarray 258
#define yassign 259
#define ybegin 260
#define ycaret 261
#define ycase 262
#define ycolon 263
#define ycomma 264
#define yconst 265
#define ydispose 266
#define ydiv 267
#define ydivide 268
#define ydo 269
#define ydot 270
#define ydotdot 271
#define ydownto 272
#define yelse 273
#define yend 274
#define yequal 275
#define yfalse 276
#define yfor 277
#define yfunction 278
#define ygreater 279
#define ygreaterequal 280
#define yif 281
#define yin 282
#define yleftbracket 283
#define yleftparen 284
#define yless 285
#define ylessequal 286
#define yminus 287
#define ymod 288
#define ymultiply 289
#define ynew 290
#define ynil 291
#define ynot 292
#define ynotequal 293
#define ynumber 294
#define yof 295
#define yor 296
#define yplus 297
#define yprocedure 298
#define yprogram 299
#define yread 300
#define yreadln 301
#define yrecord 302
#define yrepeat 303
#define yrightbracket 304
#define yrightparen 305
#define ysemicolon 306
#define yset 307
#define ythen 308
#define yto 309
#define ytrue 310
#define ytype 311
#define yuntil 312
#define yvar 313
#define ywhile 314
#define ywrite 315
#define ywriteln 316
#define yunknown 317
#define yident 318
#define ystring 319
#define YYERRCODE 256
static const short yylhs[] = {                           -1,
    0,   14,   11,   12,   15,   15,   13,   16,   18,   18,
   22,   22,   19,   19,   24,   24,   20,   20,   26,   26,
   23,   25,   27,    9,    9,    9,    9,    8,    8,    8,
    8,    3,    3,    3,    3,    3,    4,   29,   29,   28,
   28,    6,    5,    7,   30,   30,   31,   17,   17,   32,
   32,   32,   32,   32,   32,   32,   32,   32,   32,   32,
   33,   34,   45,   34,   35,   35,   46,   36,   47,   47,
   48,   49,   49,   37,   38,   50,   39,   51,   51,   40,
   40,   40,   40,   40,   40,   52,   52,   55,   42,   54,
   54,   56,   56,   56,   44,   53,   53,   57,   41,   58,
   41,   43,   43,   59,   59,   61,   61,   62,   62,   64,
   64,   64,   64,   64,   64,   64,   64,   64,   64,   68,
   67,   66,   66,   69,   69,   70,   70,   21,   21,   21,
   73,   71,   74,   72,    1,    1,    2,    2,   75,   76,
   76,   77,   77,   10,   10,   65,   65,   65,   65,   65,
   63,   63,   63,   60,   60,   60,   60,   60,   60,   60,
};
static const short yylen[] = {                            2,
    1,    0,    7,    3,    1,    3,    4,    4,    2,    0,
    2,    3,    0,    2,    2,    3,    2,    0,    2,    3,
    3,    3,    3,    2,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    7,    0,    3,    3,
    3,    3,    3,    2,    1,    3,    3,    1,    3,    1,
    1,    1,    1,    1,    1,    1,    1,    1,    3,    0,
    3,    1,    0,    3,    5,    7,    0,    5,    1,    3,
    3,    1,    3,    4,    4,    0,    9,    1,    1,    4,
    1,    4,    4,    1,    4,    1,    3,    0,    3,    0,
    2,    2,    3,    1,    3,    1,    3,    0,    5,    0,
    5,    1,    3,    1,    2,    1,    3,    1,    3,    1,
    1,    1,    1,    1,    1,    3,    2,    1,    1,    0,
    3,    3,    2,    1,    3,    1,    3,    0,    3,    3,
    0,    4,    0,    6,    2,    3,    2,    3,    3,    1,
    3,    4,    3,    1,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
};
static const short yydefred[] = {                         0,
    0,    0,    1,    0,    0,    0,    5,    0,    2,    0,
    4,    0,    6,    0,    0,    0,    0,    0,    0,    0,
    3,    0,    0,    0,    0,    0,   11,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,   48,   50,   51,   52,   53,   54,   55,   56,   57,
   58,    0,    0,    0,    0,    0,  128,   31,  145,   27,
   29,  144,   30,   28,   26,   25,   21,    0,   12,    0,
  112,    0,    0,  113,    0,  110,  111,    0,  114,    0,
  115,    0,    0,    0,    0,  108,  118,  119,    0,   76,
    0,    0,    0,    0,    0,    0,    0,    0,    0,   90,
    7,    0,    0,    0,    0,   15,    0,    0,    0,    0,
   24,   59,  123,    0,    0,  124,    0,  117,    0,    0,
    0,  154,  157,  159,  160,  156,  158,  155,    0,  152,
  153,  151,    0,  150,  148,  147,  149,  146,    0,  100,
    0,    0,   98,   88,   86,    0,    0,    0,    0,   96,
    0,    0,    0,   64,    0,   49,   61,    0,    0,    0,
    0,   32,   22,   33,   36,   35,   34,   16,    0,    0,
   19,    0,    0,    0,    0,    0,    0,    0,    0,  122,
  116,  121,   72,    0,   69,    0,  103,    0,  109,    0,
    0,    0,    0,    0,   80,   82,   75,   74,    0,   83,
   85,    0,   94,    0,    0,   91,    0,   44,    0,    0,
   45,    0,   23,   20,    0,    0,  131,    0,  129,  130,
  127,  125,   68,    0,    0,    0,  101,    0,    0,   65,
   99,   87,   97,   95,   92,    0,    0,    0,   38,    0,
   42,    0,   43,    0,  138,  136,    0,  133,   70,   71,
   73,   79,   78,    0,   67,   93,    0,    0,    0,   47,
   46,    0,    0,    0,  140,  132,    0,    0,   66,   41,
   40,    0,    0,    0,    0,  139,    0,    0,    0,   39,
    0,    0,  143,  141,  134,   77,   37,  142,
};
static const short yydgoto[] = {                          2,
  174,  175,  163,  164,  165,  166,  167,   66,  114,   80,
    3,    6,   15,   12,  107,   16,   41,   17,   24,   57,
  110,   19,   20,   54,   55,  108,  109,  239,  259,  210,
  211,   42,   43,   44,   45,   46,   47,   48,   49,   50,
   51,   81,  150,  154,   99,  230,  184,  185,  186,  141,
  254,  146,  151,  155,  100,  206,  193,  190,   83,  129,
   84,   85,  133,   86,  139,   87,   88,  119,  115,  116,
  176,  177,  247,  267,  245,  264,  265,
};
static const short yysindex[] = {                      -274,
 -283,    0,    0, -236, -272, -220,    0, -248,    0, -257,
    0, -171,    0, -221, -159, -147, -194, -133, -221, -186,
    0, -178, -168, -157,  260, -144,    0, -178,  -94, -116,
 -154,  -94, -112, -103,  -83, -178,  -94,  -65,  -55,    0,
 -187,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,  -36,  -44, -168,  -71, -272,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0, -149,    0, -130,
    0,  -77,  -94,    0,  249,    0,    0,    0,    0,  249,
    0,  -51,  301, -263,   63,    0,    0,    0,  -72,    0,
  -68,  -70,  -54,  -54, -284,  -10,  -94,  -94,  -29,    0,
    0, -178,  -94, -244,  -41,    0, -155, -272,  -40, -258,
    0,    0,    0,   -3, -245,    0,  -34,    0,  -29, -263,
  260,    0,    0,    0,    0,    0,    0,    0,  -94,    0,
    0,    0,  249,    0,    0,    0,    0,    0,  249,    0,
   10, -178,    0,    0,    0, -243, -241,  -94, -178,    0,
 -238, -237,  -94,    0, -232,    0,    0,   -6,  -35, -272,
  -13,    0,    0,    0,    0,    0,    0,    0, -244,  -22,
    0,  -31,  -20,   -9,   33,   -1,    1,  260,  260,    0,
    0,    0,    0, -120,    0,  -98,    0,   63,    0,    4,
  -94,   27,    8,  -54,    0,    0,    0,    0,  -94,    0,
    0, -227,    0,  -12,  -94,    0, -161,    0,  -85, -104,
    0, -161,    0,    0,   20,   20,    0,    5,    0,    0,
    0,    0,    0,  260, -178,  260,    0, -162, -178,    0,
    0,    0,    0,    0,    0, -175,   37,   45,    0, -244,
    0, -272,    0,  -75,    0,    0, -171,    0,    0,    0,
    0,    0,    0,  -94,    0,    0,    2, -149, -173,    0,
    0, -272,  -14,  -53,    0,    0,   16,   56,    0,    0,
    0, -161,   31,   -2,   18,    0,  -75, -171, -178,    0,
 -244,   19,    0,    0,    0,    0,    0,    0,
};
static const short yyrindex[] = {                         0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0, -218,    0,    0,    0,    0, -242,    0, -213,    0,
    0,  -59,    0, -164,    0,    0,    0,  -59,    0,    0,
    0,    0,    0,    0,  -78, -205,    0,    0,  -61, -229,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0, -208,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    6,    0,    0,
    0,    0, -121,  198,  106,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0, -135,    0,    0,    0,    0,    0,  -42,    0,   78,
    0,    0,    0, -172,    0,    0,    0,    0,    0,  244,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,  -52,    0,    0,    0,    0,    0,    0,  -52,    0,
    0,    0,    0,    0,   60,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,  152,    0,    0,
    0,  -80,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,   80,   35,    0,    0,    0,    0,
    0,    0,    0,    0,  -59,    0,    0,    0,  -52,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0, -218,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0, -218,  -52,    0,
    0,    0,    0,    0,    0,    0,    0,    0,
};
static const short yygindex[] = {                         0,
    0,    0, -165,    0,    0,    0,    0,  -66,  -15,  -19,
    0,    0, -143,    0,   -5,    0,    3,    0,    0,    0,
    0,    0,  325,    0,  296,    0,  246, -203,    0,    0,
  116,  -99,    0,    0,    0,    0,    0,    0,    0,    0,
    0,  -21,  -24,  240,    0,  105,    0,  137,    0,    0,
    0,  268,  -87,    0,    0,    0,    0,    0,  234,    0,
  287,  238,    0,  -63,    0,    0,    0,    0,    0,  194,
    0,    0,    0,    0,  158,    0,   99,
};
#define YYTABLESIZE 594
static const short yytable[] = {                          8,
   52,  111,  156,  213,   82,   68,   52,   91,  243,   67,
  152,  118,   96,  158,   52,   10,  159,   13,  179,  172,
  194,  102,  194,  130,    1,  199,  199,  148,  203,   88,
   70,   88,  131,  132,    4,   13,  199,  204,   95,  173,
   88,   10,  192,   62,   62,    7,    9,    5,  117,  198,
  205,   14,   68,   88,   63,   13,   11,  160,  180,   10,
   13,  195,  161,  196,    9,  202,  200,  201,  280,   14,
   13,  145,  145,  162,  260,  189,   62,  234,  157,   10,
   52,   28,   62,   29,    9,    9,  101,   30,  199,   14,
  272,  126,   10,   14,   10,   18,   18,    9,   31,    9,
   60,   68,   32,  266,   14,  183,   60,  169,   10,  252,
   21,   33,   22,   18,   58,  287,   23,  236,  102,   27,
   52,   34,   35,  197,   36,  250,   58,   52,  256,  255,
  273,  126,   61,   18,  285,   37,   38,   39,   60,   40,
  238,   25,  102,  112,   61,  238,  253,  102,   63,   53,
  102,  102,  102,  223,  209,   56,   64,  237,   68,   68,
   63,   69,  221,   90,  225,  226,  228,   89,   64,  241,
   60,   92,  232,  102,  233,  102,   60,  240,   10,  286,
   93,   71,  102,  102,  102,  224,  102,  102,   72,   73,
  102,  271,   59,   67,   81,   81,   74,   75,   58,   76,
   94,  242,   62,   52,   68,  238,   68,   52,  183,   59,
  251,   84,   84,   60,   60,   77,   61,   17,   97,   62,
   60,   60,  103,   78,   79,   67,  113,   81,   98,  268,
  104,   67,   63,   81,  106,   17,  209,  262,  263,  142,
   64,   65,    7,  121,   84,  140,   60,  143,  275,   10,
   84,  276,  277,   60,  153,   17,  274,   52,  149,   60,
  282,   10,   88,  144,  168,  171,   88,  178,  191,   88,
  181,  263,   88,   88,   88,   88,  207,   88,   88,   88,
   88,  212,  208,  214,   88,   88,  215,   88,   88,  120,
   88,   88,   88,   88,   88,  218,  217,  216,   88,  229,
   88,   88,   88,  244,  219,  235,  220,  257,  227,   88,
   88,   88,  231,   88,   88,  258,   89,   88,   89,  134,
  270,  278,  248,   89,  279,  281,   89,   89,   89,  135,
  136,   89,   89,   89,   89,  283,  288,    8,   89,   89,
  135,   89,  137,   26,   89,   89,   89,   89,   89,  105,
  137,  138,   89,  170,   89,   89,   89,  261,  182,  269,
  249,  147,  187,   89,   89,   89,  120,   89,   89,  106,
  188,   89,  222,  246,  106,  284,    0,  106,  106,  106,
  106,    0,    0,    0,  106,  106,    0,  106,    0,    0,
  106,  106,  106,    0,    0,    0,    0,    0,  106,    0,
  106,  106,  106,    0,    0,    0,    0,    0,    0,  106,
  106,  106,    0,  106,  106,  107,    0,  106,    0,    0,
  107,    0,    0,  107,  107,  107,  107,    0,    0,    0,
  107,  107,    0,  107,    0,    0,  107,  107,  107,    0,
    0,    0,    0,    0,  107,    0,  107,  107,  107,    0,
    0,    0,    0,    0,    0,  107,  107,  107,    0,  107,
  107,  104,    0,  107,    0,    0,  104,    0,    0,  104,
  104,  104,  104,    0,    0,    0,  104,  104,    0,  104,
    0,    0,  104,  104,    0,    0,    0,    0,    0,    0,
  104,    0,  104,    0,    0,    0,    0,    0,    0,    0,
    0,  104,  104,  104,    0,  104,  104,  105,    0,  104,
    0,    0,  105,    0,    0,  105,  105,  105,  105,    0,
    0,    0,  105,  105,   71,  105,    0,    0,  105,  105,
    0,   72,   73,    0,    0,   58,  105,    0,  105,   74,
   75,    0,   76,    0,    0,    0,   59,  105,  105,  105,
   60,  105,  105,   61,    0,  105,   62,    0,   77,    0,
    0,    0,    0,    0,    0,    0,   78,   79,    0,   63,
    0,    0,    0,    0,    0,  122,    0,   64,   65,  123,
  124,    0,  125,    0,    0,  126,  127,    0,    0,    0,
    0,    0,    0,  128,
};
static const short yycheck[] = {                          5,
   22,   68,  102,  169,   29,   25,   28,   32,  212,   25,
   98,   75,   37,  258,   36,  264,  261,  260,  264,  278,
  264,  306,  264,  287,  299,  264,  264,  312,  261,  259,
   28,  261,  296,  297,  318,  278,  264,  270,   36,  298,
  270,  260,  142,  273,  274,  318,  260,  284,   73,  149,
  283,  260,   72,  283,  284,  298,  305,  302,  304,  278,
  318,  305,  307,  305,  278,  153,  305,  305,  272,  278,
  313,   93,   94,  318,  240,  139,  306,  305,  103,  298,
  102,  260,  312,  262,  298,  306,  274,  266,  264,  298,
  264,  264,  311,  265,  313,  260,  318,  311,  277,  313,
  306,  121,  281,  247,  313,  121,  312,  263,  264,  272,
  270,  290,  260,  278,  276,  281,  311,  205,  306,  306,
  142,  300,  301,  148,  303,  225,  276,  149,  304,  229,
  304,  304,  294,  298,  278,  314,  315,  316,  274,  318,
  207,  275,  264,  274,  294,  212,  309,  269,  310,  318,
  272,  273,  274,  274,  160,  313,  318,  319,  178,  179,
  310,  306,  178,  318,  263,  264,  191,  284,  318,  274,
  306,  284,  194,  295,  199,  306,  312,  263,  264,  279,
  284,  276,  304,  305,  306,  306,  308,  309,  283,  284,
  312,  258,  287,  274,  273,  274,  291,  292,  276,  294,
  284,  306,  297,  225,  224,  272,  226,  229,  224,  287,
  226,  273,  274,  291,  274,  310,  294,  260,  284,  297,
  273,  274,  259,  318,  319,  306,  304,  306,  284,  254,
  275,  312,  310,  312,  306,  278,  242,  313,  244,  308,
  318,  319,  318,  295,  306,  318,  306,  318,  263,  264,
  312,  305,  306,  306,  284,  298,  262,  279,  269,  312,
  263,  264,  257,  318,  306,  306,  261,  271,  259,  264,
  305,  277,  267,  268,  269,  270,  283,  272,  273,  274,
  275,  295,  318,  306,  279,  280,  318,  282,  283,  284,
  285,  286,  287,  288,  289,  263,  306,  318,  293,  273,
  295,  296,  297,  284,  306,  318,  306,  271,  305,  304,
  305,  306,  305,  308,  309,  271,  257,  312,  259,  257,
  319,  306,  318,  264,  269,  295,  267,  268,  269,  267,
  268,  272,  273,  274,  275,  318,  318,  260,  279,  280,
  306,  282,  263,   19,  285,  286,  287,  288,  289,   54,
  288,  289,  293,  108,  295,  296,  297,  242,  119,  255,
  224,   94,  129,  304,  305,  306,   80,  308,  309,  264,
  133,  312,  179,  216,  269,  277,   -1,  272,  273,  274,
  275,   -1,   -1,   -1,  279,  280,   -1,  282,   -1,   -1,
  285,  286,  287,   -1,   -1,   -1,   -1,   -1,  293,   -1,
  295,  296,  297,   -1,   -1,   -1,   -1,   -1,   -1,  304,
  305,  306,   -1,  308,  309,  264,   -1,  312,   -1,   -1,
  269,   -1,   -1,  272,  273,  274,  275,   -1,   -1,   -1,
  279,  280,   -1,  282,   -1,   -1,  285,  286,  287,   -1,
   -1,   -1,   -1,   -1,  293,   -1,  295,  296,  297,   -1,
   -1,   -1,   -1,   -1,   -1,  304,  305,  306,   -1,  308,
  309,  264,   -1,  312,   -1,   -1,  269,   -1,   -1,  272,
  273,  274,  275,   -1,   -1,   -1,  279,  280,   -1,  282,
   -1,   -1,  285,  286,   -1,   -1,   -1,   -1,   -1,   -1,
  293,   -1,  295,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,  304,  305,  306,   -1,  308,  309,  264,   -1,  312,
   -1,   -1,  269,   -1,   -1,  272,  273,  274,  275,   -1,
   -1,   -1,  279,  280,  276,  282,   -1,   -1,  285,  286,
   -1,  283,  284,   -1,   -1,  276,  293,   -1,  295,  291,
  292,   -1,  294,   -1,   -1,   -1,  287,  304,  305,  306,
  291,  308,  309,  294,   -1,  312,  297,   -1,  310,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,  318,  319,   -1,  310,
   -1,   -1,   -1,   -1,   -1,  275,   -1,  318,  319,  279,
  280,   -1,  282,   -1,   -1,  285,  286,   -1,   -1,   -1,
   -1,   -1,   -1,  293,
};
#define YYFINAL 2
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 319
#if YYDEBUG
static const char *yyname[] = {

"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"yand","yarray","yassign",
"ybegin","ycaret","ycase","ycolon","ycomma","yconst","ydispose","ydiv",
"ydivide","ydo","ydot","ydotdot","ydownto","yelse","yend","yequal","yfalse",
"yfor","yfunction","ygreater","ygreaterequal","yif","yin","yleftbracket",
"yleftparen","yless","ylessequal","yminus","ymod","ymultiply","ynew","ynil",
"ynot","ynotequal","ynumber","yof","yor","yplus","yprocedure","yprogram",
"yread","yreadln","yrecord","yrepeat","yrightbracket","yrightparen",
"ysemicolon","yset","ythen","yto","ytrue","ytype","yuntil","yvar","ywhile",
"ywrite","ywriteln","yunknown","yident","ystring",
};
static const char *yyrule[] = {
"$accept : CompilationUnit",
"CompilationUnit : ProgramModule",
"$$1 :",
"ProgramModule : yprogram yident ProgramParameters ysemicolon $$1 Block ydot",
"ProgramParameters : yleftparen IdentList yrightparen",
"IdentList : yident",
"IdentList : IdentList ycomma yident",
"Block : Declarations ybegin StatementSequence yend",
"Declarations : ConstantDefBlock TypeDefBlock VariableDeclBlock SubprogDeclList",
"ConstantDefBlock : yconst ConstDefList",
"ConstantDefBlock :",
"ConstDefList : ConstantDef ysemicolon",
"ConstDefList : ConstDefList ConstantDef ysemicolon",
"TypeDefBlock :",
"TypeDefBlock : ytype TypeDefList",
"TypeDefList : TypeDef ysemicolon",
"TypeDefList : TypeDefList TypeDef ysemicolon",
"VariableDeclBlock : yvar VariableDeclList",
"VariableDeclBlock :",
"VariableDeclList : VariableDecl ysemicolon",
"VariableDeclList : VariableDeclList VariableDecl ysemicolon",
"ConstantDef : yident yequal ConstExpression",
"TypeDef : yident yequal Type",
"VariableDecl : IdentList ycolon Type",
"ConstExpression : UnaryOperator ConstFactor",
"ConstExpression : ConstFactor",
"ConstExpression : ystring",
"ConstExpression : ynil",
"ConstFactor : yident",
"ConstFactor : ynumber",
"ConstFactor : ytrue",
"ConstFactor : yfalse",
"Type : yident",
"Type : ArrayType",
"Type : PointerType",
"Type : RecordType",
"Type : SetType",
"ArrayType : yarray yleftbracket Subrange SubrangeList yrightbracket yof Type",
"SubrangeList :",
"SubrangeList : SubrangeList ycomma Subrange",
"Subrange : ConstFactor ydotdot ConstFactor",
"Subrange : ystring ydotdot ystring",
"RecordType : yrecord FieldListSequence yend",
"SetType : yset yof Subrange",
"PointerType : ycaret yident",
"FieldListSequence : FieldList",
"FieldListSequence : FieldListSequence ysemicolon FieldList",
"FieldList : IdentList ycolon Type",
"StatementSequence : Statement",
"StatementSequence : StatementSequence ysemicolon Statement",
"Statement : Assignment",
"Statement : ProcedureCall",
"Statement : IfStatement",
"Statement : CaseStatement",
"Statement : WhileStatement",
"Statement : RepeatStatement",
"Statement : ForStatement",
"Statement : IOStatement",
"Statement : MemoryStatement",
"Statement : ybegin StatementSequence yend",
"Statement :",
"Assignment : Designator yassign Expression",
"ProcedureCall : yident",
"$$2 :",
"ProcedureCall : yident $$2 ActualParameters",
"IfStatement : yif Expression ythen Statement EndIf",
"IfStatement : yif Expression ythen Statement yelse Statement EndIf",
"EndIf :",
"CaseStatement : ycase Expression yof CaseList yend",
"CaseList : Case",
"CaseList : CaseList ysemicolon Case",
"Case : CaseLabelList ycolon Statement",
"CaseLabelList : ConstExpression",
"CaseLabelList : CaseLabelList ycomma ConstExpression",
"WhileStatement : ywhile Expression ydo Statement",
"RepeatStatement : yrepeat StatementSequence yuntil Expression",
"$$3 :",
"ForStatement : yfor yident $$3 yassign Expression WhichWay Expression ydo Statement",
"WhichWay : yto",
"WhichWay : ydownto",
"IOStatement : yread yleftparen DesignatorList yrightparen",
"IOStatement : yreadln",
"IOStatement : yreadln yleftparen DesignatorList yrightparen",
"IOStatement : ywrite yleftparen ExpList yrightparen",
"IOStatement : ywriteln",
"IOStatement : ywriteln yleftparen ExpList yrightparen",
"DesignatorList : Designator",
"DesignatorList : DesignatorList ycomma Designator",
"$$4 :",
"Designator : yident $$4 DesignatorStuff",
"DesignatorStuff :",
"DesignatorStuff : DesignatorStuff theDesignatorStuff",
"theDesignatorStuff : ydot yident",
"theDesignatorStuff : yleftbracket ExpList yrightbracket",
"theDesignatorStuff : ycaret",
"ActualParameters : yleftparen ExpList yrightparen",
"ExpList : Expression",
"ExpList : ExpList ycomma Expression",
"$$5 :",
"MemoryStatement : ynew yleftparen yident $$5 yrightparen",
"$$6 :",
"MemoryStatement : ydispose yleftparen yident $$6 yrightparen",
"Expression : SimpleExpression",
"Expression : SimpleExpression Relation SimpleExpression",
"SimpleExpression : TermExpr",
"SimpleExpression : UnaryOperator TermExpr",
"TermExpr : Term",
"TermExpr : TermExpr AddOperator Term",
"Term : Factor",
"Term : Term MultOperator Factor",
"Factor : ynumber",
"Factor : ytrue",
"Factor : yfalse",
"Factor : ynil",
"Factor : ystring",
"Factor : Designator",
"Factor : yleftparen Expression yrightparen",
"Factor : ynot Factor",
"Factor : Setvalue",
"Factor : FunctionCall",
"$$7 :",
"FunctionCall : yident $$7 ActualParameters",
"Setvalue : yleftbracket ElementList yrightbracket",
"Setvalue : yleftbracket yrightbracket",
"ElementList : Element",
"ElementList : ElementList ycomma Element",
"Element : ConstExpression",
"Element : ConstExpression ydotdot ConstExpression",
"SubprogDeclList :",
"SubprogDeclList : SubprogDeclList ProcedureDecl ysemicolon",
"SubprogDeclList : SubprogDeclList FunctionDecl ysemicolon",
"$$8 :",
"ProcedureDecl : ProcedureHeading ysemicolon $$8 Block",
"$$9 :",
"FunctionDecl : FunctionHeading ycolon yident $$9 ysemicolon Block",
"ProcedureHeading : yprocedure yident",
"ProcedureHeading : yprocedure yident FormalParameters",
"FunctionHeading : yfunction yident",
"FunctionHeading : yfunction yident FormalParameters",
"FormalParameters : yleftparen FormalParamList yrightparen",
"FormalParamList : OneFormalParam",
"FormalParamList : FormalParamList ysemicolon OneFormalParam",
"OneFormalParam : yvar IdentList ycolon yident",
"OneFormalParam : IdentList ycolon yident",
"UnaryOperator : yplus",
"UnaryOperator : yminus",
"MultOperator : ymultiply",
"MultOperator : ydivide",
"MultOperator : ydiv",
"MultOperator : ymod",
"MultOperator : yand",
"AddOperator : yplus",
"AddOperator : yminus",
"AddOperator : yor",
"Relation : yequal",
"Relation : ynotequal",
"Relation : yless",
"Relation : ygreater",
"Relation : ylessequal",
"Relation : ygreaterequal",
"Relation : yin",

};
#endif

int      yydebug;
int      yynerrs;

int      yyerrflag;
int      yychar;
YYSTYPE  yyval;
YYSTYPE  yylval;

/* define the initial stack-sizes */
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH  YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 500
#define YYMAXDEPTH  500
#endif
#endif

#define YYINITSTACKSIZE 500

typedef struct {
    unsigned stacksize;
    short    *s_base;
    short    *s_mark;
    short    *s_last;
    YYSTYPE  *l_base;
    YYSTYPE  *l_mark;
} YYSTACKDATA;
/* variables for the parser stack */
static YYSTACKDATA yystack;
#line 438 "grammar.y"

/* program section */

void yyerror(const char *s) {
   cout << s << endl;
}

extern int yylex();

#line 640 "y.tab.c"

#if YYDEBUG
#include <stdio.h>		/* needed for printf */
#endif

#include <stdlib.h>	/* needed for malloc, etc */
#include <string.h>	/* needed for memset */

/* allocate initial stack or double stack size, up to YYMAXDEPTH */
static int yygrowstack(YYSTACKDATA *data)
{
    int i;
    unsigned newsize;
    short *newss;
    YYSTYPE *newvs;

    if ((newsize = data->stacksize) == 0)
        newsize = YYINITSTACKSIZE;
    else if (newsize >= YYMAXDEPTH)
        return -1;
    else if ((newsize *= 2) > YYMAXDEPTH)
        newsize = YYMAXDEPTH;

    i = data->s_mark - data->s_base;
    newss = (short *)realloc(data->s_base, newsize * sizeof(*newss));
    if (newss == 0)
        return -1;

    data->s_base = newss;
    data->s_mark = newss + i;

    newvs = (YYSTYPE *)realloc(data->l_base, newsize * sizeof(*newvs));
    if (newvs == 0)
        return -1;

    data->l_base = newvs;
    data->l_mark = newvs + i;

    data->stacksize = newsize;
    data->s_last = data->s_base + newsize - 1;
    return 0;
}

#if YYPURE || defined(YY_NO_LEAKS)
static void yyfreestack(YYSTACKDATA *data)
{
    free(data->s_base);
    free(data->l_base);
    memset(data, 0, sizeof(*data));
}
#else
#define yyfreestack(data) /* nothing */
#endif

#define YYABORT  goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR  goto yyerrlab

int
YYPARSE_DECL()
{
    int yym, yyn, yystate;
#if YYDEBUG
    const char *yys;

    if ((yys = getenv("YYDEBUG")) != 0)
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = YYEMPTY;
    yystate = 0;

#if YYPURE
    memset(&yystack, 0, sizeof(yystack));
#endif

    if (yystack.s_base == NULL && yygrowstack(&yystack)) goto yyoverflow;
    yystack.s_mark = yystack.s_base;
    yystack.l_mark = yystack.l_base;
    yystate = 0;
    *yystack.s_mark = 0;

yyloop:
    if ((yyn = yydefred[yystate]) != 0) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = YYLEX) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yystack.s_mark >= yystack.s_last && yygrowstack(&yystack))
        {
            goto yyoverflow;
        }
        yystate = yytable[yyn];
        *++yystack.s_mark = yytable[yyn];
        *++yystack.l_mark = yylval;
        yychar = YYEMPTY;
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;

    yyerror("syntax error");

    goto yyerrlab;

yyerrlab:
    ++yynerrs;

yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yystack.s_mark]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yystack.s_mark, yytable[yyn]);
#endif
                if (yystack.s_mark >= yystack.s_last && yygrowstack(&yystack))
                {
                    goto yyoverflow;
                }
                yystate = yytable[yyn];
                *++yystack.s_mark = yytable[yyn];
                *++yystack.l_mark = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yystack.s_mark);
#endif
                if (yystack.s_mark <= yystack.s_base) goto yyabort;
                --yystack.s_mark;
                --yystack.l_mark;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = YYEMPTY;
        goto yyloop;
    }

yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    if (yym)
        yyval = yystack.l_mark[1-yym];
    else
        memset(&yyval, 0, sizeof yyval);
    switch (yyn)
    {
case 2:
#line 49 "grammar.y"
	{
                                    createProgramScope(yystack.l_mark[-2].text);
                                }
break;
case 3:
#line 53 "grammar.y"
	{
                                    exitScope();
                                }
break;
case 5:
#line 60 "grammar.y"
	{
                                    addIdent(yystack.l_mark[0].text);
                                }
break;
case 6:
#line 64 "grammar.y"
	{
                                    addIdent(yystack.l_mark[0].text);
                                }
break;
case 14:
#line 86 "grammar.y"
	{
                                    /*loop throught all pointers*/
                                    /*add to symbol table*/
                                    checkPointers();
                                }
break;
case 17:
#line 96 "grammar.y"
	{
                                    
                                }
break;
case 21:
#line 105 "grammar.y"
	{
                                    createConstant(yystack.l_mark[-2].text, yystack.l_mark[0].constvalue);
                                }
break;
case 22:
#line 110 "grammar.y"
	{
                                    createTypeSymbol(yystack.l_mark[-2].text, yystack.l_mark[0].type);
                                }
break;
case 23:
#line 115 "grammar.y"
	{
                                    /*checkPointers();*/
                                    createVariables(yystack.l_mark[0].type);
                                }
break;
case 24:
#line 124 "grammar.y"
	{
                                    yystack.l_mark[0].constvalue->setOperator(yystack.l_mark[-1].unaryop);
                                    yyval.constvalue = yystack.l_mark[0].constvalue;
                                }
break;
case 26:
#line 130 "grammar.y"
	{
                                    createConstStringValue(yyval.constvalue, yystack.l_mark[0].text);
                                }
break;
case 27:
#line 134 "grammar.y"
	{
                                    createConstNilValue(yyval.constvalue);
                                }
break;
case 28:
#line 139 "grammar.y"
	{
                                    createConstSymbolValue(yyval.constvalue, yystack.l_mark[0].text);
                                }
break;
case 29:
#line 143 "grammar.y"
	{
                                    createConstNumberValue(yyval.constvalue, yystack.l_mark[0].text);
                                }
break;
case 30:
#line 147 "grammar.y"
	{
                                    createConstBoolValue(yyval.constvalue, "true");
                                }
break;
case 31:
#line 151 "grammar.y"
	{
                                    createConstBoolValue(yyval.constvalue, "false");
                                }
break;
case 32:
#line 155 "grammar.y"
	{
                                    getTypeOfSymbol(yystack.l_mark[0].text, yyval.type);
                                }
break;
case 34:
#line 160 "grammar.y"
	{
                                    yyval.type = yystack.l_mark[0].type;
                                }
break;
case 37:
#line 168 "grammar.y"
	{
                                    createArrayType(yyval.type, yystack.l_mark[0].type);
                                }
break;
case 40:
#line 176 "grammar.y"
	{
                                    createConstRange(yystack.l_mark[-2].constvalue, yystack.l_mark[0].constvalue);
                                }
break;
case 41:
#line 180 "grammar.y"
	{
                                    createStringRange(yystack.l_mark[-2].text, yystack.l_mark[0].text);
                                }
break;
case 42:
#line 185 "grammar.y"
	{
                                    createRecordType(yyval.type);
                                }
break;
case 43:
#line 190 "grammar.y"
	{
                                    createSetType(yyval.type);
                                }
break;
case 44:
#line 195 "grammar.y"
	{
                                    createPointer(yyval.type, yystack.l_mark[0].text);
                                }
break;
case 47:
#line 203 "grammar.y"
	{
                                    createVariableList(yystack.l_mark[0].type);
                                }
break;
case 51:
#line 215 "grammar.y"
	{
                          /*Handle procedue calls*/
                      }
break;
case 62:
#line 231 "grammar.y"
	{
                                    printf("%s ", yystack.l_mark[0].text);
                                }
break;
case 63:
#line 235 "grammar.y"
	{
                                    printf("%s ", yystack.l_mark[0].text);
                                }
break;
case 76:
#line 260 "grammar.y"
	{
                                    printf("%s ", yystack.l_mark[0].text);
                                }
break;
case 88:
#line 282 "grammar.y"
	{
                                   printf("%s ", yystack.l_mark[0].text);
                                }
break;
case 92:
#line 291 "grammar.y"
	{
                                    printf("%s ", yystack.l_mark[0].text);
                                }
break;
case 98:
#line 303 "grammar.y"
	{
                                    printf("%s ", yystack.l_mark[0].text);
                                }
break;
case 100:
#line 308 "grammar.y"
	{
                                    printf("%s ", yystack.l_mark[0].text);
                                }
break;
case 120:
#line 344 "grammar.y"
	{
                                    printf("%s ", yystack.l_mark[0].text);
                                }
break;
case 131:
#line 366 "grammar.y"
	{
                                createProcedureDecl(yystack.l_mark[-1].procedure);
                            }
break;
case 132:
#line 370 "grammar.y"
	{
                                exitScope();
                            }
break;
case 133:
#line 375 "grammar.y"
	{
                                createFunctionDecl(yystack.l_mark[0].text, yystack.l_mark[-2].function);
                            }
break;
case 134:
#line 379 "grammar.y"
	{
                                exitScope();
                            }
break;
case 135:
#line 384 "grammar.y"
	{
                                    createProcedure(yystack.l_mark[0].text, yyval.procedure);
                                }
break;
case 136:
#line 388 "grammar.y"
	{
                                    createProcedureWithParams(yystack.l_mark[-1].text, yyval.procedure);
                                }
break;
case 137:
#line 393 "grammar.y"
	{
                                    createFunction(yystack.l_mark[0].text, yyval.function);
                                }
break;
case 138:
#line 397 "grammar.y"
	{
                                    createFunctionWithParams(yystack.l_mark[-1].text, yyval.function);
                                }
break;
case 142:
#line 407 "grammar.y"
	{
                                    createParameter(yystack.l_mark[0].text);
                                    
                                }
break;
case 143:
#line 412 "grammar.y"
	{
                                   createParameter(yystack.l_mark[0].text);
                                    
                                }
break;
case 144:
#line 421 "grammar.y"
	{
                                    yyval.unaryop = PLUS;
                                }
break;
case 145:
#line 425 "grammar.y"
	{
                                    yyval.unaryop = MINUS;
                                }
break;
#line 1128 "y.tab.c"
    }
    yystack.s_mark -= yym;
    yystate = *yystack.s_mark;
    yystack.l_mark -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yystack.s_mark = YYFINAL;
        *++yystack.l_mark = yyval;
        if (yychar < 0)
        {
            if ((yychar = YYLEX) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yystack.s_mark, yystate);
#endif
    if (yystack.s_mark >= yystack.s_last && yygrowstack(&yystack))
    {
        goto yyoverflow;
    }
    *++yystack.s_mark = (short) yystate;
    *++yystack.l_mark = yyval;
    goto yyloop;

yyoverflow:
    yyerror("yacc stack overflow");

yyabort:
    yyfreestack(&yystack);
    return (1);

yyaccept:
    yyfreestack(&yystack);
    return (0);
}
